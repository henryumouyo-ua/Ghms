const collections = {
  countries: [],
  states: [],
  hospitals: [],
  doctors: [],
  patients: [],
  appointments: [],
  requests: []
};

const endpoints = {
  countries: "/api/countries",
  states: "/api/states-provinces",
  hospitals: "/api/hospitals",
  doctors: "/api/doctors",
  patients: "/api/patients",
  appointments: "/api/appointments",
  requests: "/api/record-requests"
};

const optionLabels = {
  countries: item => `${item.name} (${item.isoCode})`,
  states: item => `${item.name}${item.code ? ` · ${item.code}` : ""}`,
  hospitals: item => item.name,
  doctors: item => `${item.fullName} · ${item.specialization}`,
  patients: item => `${item.fullName} · #${item.id}`
};

let toastTimeout;

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(path, {
      ...options,
      headers: {
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers
      }
    });
  } catch {
    throw new Error("Could not reach the API. Check that the application and database are running.");
  }

  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body.fieldErrors) {
        detail = Object.entries(body.fieldErrors).map(([field, message]) => `${field}: ${message}`).join("; ");
      } else if (body.error) {
        detail = body.error;
      } else if (body.message) {
        detail = body.message;
      }
    } catch {
      detail = `${detail}. Please try again.`;
    }
    throw new Error(detail);
  }

  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

function showToast(message, isError = false) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("visible");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("visible"), 4200);
}

function objectLabel(value) {
  if (value == null) return "—";
  if (typeof value !== "object") return String(value);
  if (value.fullName) return value.fullName;
  if (value.name) return value.name;
  if (value.id != null) return `#${value.id}`;
  return "—";
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium", timeStyle: "short"
  }).format(date);
}

function renderTable(target, columns, rows, emptyMessage = "Nothing here yet. Add a record to get started.") {
  const container = typeof target === "string" ? document.querySelector(target) : target;
  if (!container) return;
  container.replaceChildren();
  if (!rows?.length) {
    const empty = document.createElement("div");
    empty.className = "table-empty";
    empty.textContent = emptyMessage;
    container.append(empty);
    return;
  }

  const table = document.createElement("table");
  table.className = "data-table";
  const head = document.createElement("thead");
  const headingRow = document.createElement("tr");
  columns.forEach(column => {
    const cell = document.createElement("th");
    cell.textContent = column.label;
    headingRow.append(cell);
  });
  head.append(headingRow);
  const body = document.createElement("tbody");
  rows.forEach(row => {
    const tr = document.createElement("tr");
    columns.forEach(column => {
      const td = document.createElement("td");
      const value = column.value(row);
      if (column.status && value !== "—") {
        const pill = document.createElement("span");
        pill.className = `status-pill status-${String(value).toLowerCase()}`;
        pill.textContent = value;
        td.append(pill);
      } else {
        td.textContent = value == null || value === "" ? "—" : String(value);
      }
      tr.append(td);
    });
    body.append(tr);
  });
  table.append(head, body);
  container.append(table);
}

function updateCount(id, count) {
  const element = document.getElementById(id);
  if (element) element.textContent = count;
}

function renderAll() {
  updateCount("stat-patients", collections.patients.length);
  updateCount("stat-doctors", collections.doctors.length);
  updateCount("stat-appointments", collections.appointments.length);
  updateCount("stat-requests", collections.requests.filter(item => ["PENDING", "APPROVED"].includes(item.status)).length);
  updateCount("patients-count", collections.patients.length);
  updateCount("doctors-count", collections.doctors.length);
  updateCount("hospitals-count", collections.hospitals.length);
  updateCount("appointments-count", collections.appointments.length);
  updateCount("requests-count", collections.requests.length);
  updateCount("countries-count", collections.countries.length);
  updateCount("states-count", collections.states.length);

  renderTable("#overview-appointments", [
    { label: "Patient", value: item => item.patientName },
    { label: "Doctor", value: item => item.doctorName },
    { label: "Date & time", value: item => formatDate(item.appointmentDateTime) },
    { label: "Status", value: item => item.status, status: true }
  ], [...collections.appointments].sort((a, b) => String(b.appointmentDateTime).localeCompare(String(a.appointmentDateTime))).slice(0, 5), "Appointments will appear here once they are booked.");

  renderTable("#patients-table", [
    { label: "Patient", value: item => item.fullName },
    { label: "Email", value: item => item.email },
    { label: "Phone", value: item => item.phoneNumber },
    { label: "Location", value: item => [objectLabel(item.stateOrProvince), objectLabel(item.country)].filter(value => value !== "—").join(", ") || "—" },
    { label: "Status", value: item => item.active ? "Active" : "Inactive", status: true }
  ], collections.patients);

  renderTable("#appointments-table", [
    { label: "Patient", value: item => item.patientName },
    { label: "Doctor", value: item => item.doctorName },
    { label: "Hospital", value: item => item.hospitalName },
    { label: "Date & time", value: item => formatDate(item.appointmentDateTime) },
    { label: "Status", value: item => item.status, status: true },
    { label: "Reason", value: item => item.reasonForVisit }
  ], collections.appointments);

  renderTable("#hospitals-table", [
    { label: "Hospital", value: item => item.name },
    { label: "Location", value: item => [objectLabel(item.stateOrProvince), objectLabel(item.country)].filter(value => value !== "—").join(", ") || "—" },
    { label: "Address", value: item => item.address },
    { label: "Status", value: item => item.active ? "Active" : "Inactive", status: true }
  ], collections.hospitals);

  renderTable("#doctors-table", [
    { label: "Doctor", value: item => item.fullName },
    { label: "Specialization", value: item => item.specialization },
    { label: "Hospital", value: item => objectLabel(item.hospital) },
    { label: "Status", value: item => item.active ? "Active" : "Inactive", status: true }
  ], collections.doctors);

  renderTable("#requests-table", [
    { label: "Patient", value: item => item.patientName },
    { label: "Hospital", value: item => item.hospitalName },
    { label: "Appointment", value: item => item.appointmentId ? `#${item.appointmentId}` : "All records" },
    { label: "Requested", value: item => formatDate(item.createdAt) },
    { label: "Status", value: item => item.status, status: true },
    { label: "Reason", value: item => item.reason }
  ], collections.requests);

  renderTable("#countries-table", [
    { label: "Country", value: item => item.name },
    { label: "ISO code", value: item => item.isoCode },
    { label: "ID", value: item => item.id }
  ], collections.countries);

  renderTable("#states-table", [
    { label: "State / province", value: item => item.name },
    { label: "Code", value: item => item.code },
    { label: "Country", value: item => objectLabel(item.country) },
    { label: "ID", value: item => item.id }
  ], collections.states);

  populateOptions();
}

function populateOptions() {
  document.querySelectorAll("select[data-options]").forEach(select => {
    let data = collections[select.dataset.options] ?? [];
    if (select.dataset.options === "states") {
      const countryId = select.form?.querySelector('[name="countryId"]')?.value;
      if (countryId) data = data.filter(item => String(item.country?.id) === countryId);
    }
    const selected = select.value;
    const firstOption = select.options[0]?.cloneNode(true);
    select.replaceChildren();
    if (firstOption) select.append(firstOption);
    for (const item of data) {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = optionLabels[select.dataset.options]?.(item) ?? `${item.name ?? item.id}`;
      select.append(option);
    }
    if (data.some(item => String(item.id) === selected)) select.value = selected;
  });
}

async function refreshData() {
  const status = document.querySelector("#connection-status");
  status.classList.remove("online", "offline");
  status.lastChild.textContent = " Connecting";
  const results = await Promise.allSettled(Object.entries(endpoints).map(async ([key, endpoint]) => {
    const data = await request(endpoint);
    collections[key] = Array.isArray(data) ? data : [];
  }));
  const failures = results.filter(result => result.status === "rejected");
  renderAll();
  if (failures.length === results.length) {
    status.classList.add("offline");
    status.lastChild.textContent = " API offline";
    showToast(failures[0].reason.message, true);
  } else {
    status.classList.add("online");
    status.lastChild.textContent = " API connected";
    if (failures.length) showToast(`${failures.length} section(s) could not be loaded. Refresh to try again.`, true);
  }
}

function formValues(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function optionalId(value) {
  return value ? Number(value) : null;
}

async function submitJson(form, endpoint, makePayload, successMessage) {
  const submitButton = form.querySelector('button[type="submit"]');
  const label = submitButton.textContent;
  submitButton.disabled = true;
  submitButton.textContent = "Saving…";
  try {
    await request(endpoint, {
      method: "POST",
      body: JSON.stringify(makePayload(formValues(form)))
    });
    form.reset();
    showToast(successMessage);
    await refreshData();
  } catch (error) {
    showToast(error.message, true);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = label;
  }
}

function bindCreateForms() {
  document.querySelector("#country-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.countries, value => ({
      name: value.name.trim(), isoCode: value.isoCode.trim().toUpperCase()
    }), "Country added.");
  });
  document.querySelector("#state-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.states, value => ({
      name: value.name.trim(), code: value.code.trim() || null, countryId: Number(value.countryId)
    }), "State or province added.");
  });
  document.querySelector("#hospital-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.hospitals, value => ({
      name: value.name.trim(), address: value.address.trim() || null,
      countryId: Number(value.countryId), stateProvinceId: optionalId(value.stateProvinceId)
    }), "Hospital added.");
  });
  document.querySelector("#doctor-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.doctors, value => ({
      fullName: value.fullName.trim(), specialization: value.specialization.trim(), hospitalId: Number(value.hospitalId)
    }), "Doctor added.");
  });
  document.querySelector("#patient-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.patients, value => ({
      fullName: value.fullName.trim(), email: value.email.trim(), phoneNumber: value.phoneNumber.trim(),
      countryId: Number(value.countryId), stateProvinceId: optionalId(value.stateProvinceId)
    }), "Patient registered.");
  });
  document.querySelector("#appointment-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.appointments, value => ({
      patientId: Number(value.patientId), doctorId: Number(value.doctorId),
      appointmentDateTime: value.appointmentDateTime, reasonForVisit: value.reasonForVisit.trim() || null
    }), "Appointment booked.");
  });
  document.querySelector("#record-request-form").addEventListener("submit", event => {
    event.preventDefault();
    void submitJson(event.currentTarget, endpoints.requests, value => ({
      patientId: Number(value.patientId), hospitalId: Number(value.hospitalId),
      appointmentId: optionalId(value.appointmentId), reason: value.reason.trim() || null
    }), "Record request submitted.");
  });
}

function bindSearchForms() {
  document.querySelector("#doctor-search-form").addEventListener("submit", async event => {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    const params = new URLSearchParams();
    for (const key of ["countryId", "stateProvinceId", "hospitalId", "specialization"]) {
      if (values[key]?.trim()) params.set(key, values[key].trim());
    }
    await showDirectoryResults("Doctors matching your search", `/api/doctors/search?${params}`, [
      { label: "Doctor", value: item => item.fullName },
      { label: "Specialization", value: item => item.specialization },
      { label: "Hospital", value: item => objectLabel(item.hospital) }
    ]);
  });
  document.querySelector("#hospital-search-form").addEventListener("submit", async event => {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    const params = new URLSearchParams();
    for (const key of ["countryId", "stateProvinceId"]) if (values[key]) params.set(key, values[key]);
    await showDirectoryResults("Hospitals matching your search", `/api/hospitals/search?${params}`, [
      { label: "Hospital", value: item => item.name },
      { label: "Location", value: item => [objectLabel(item.stateOrProvince), objectLabel(item.country)].filter(value => value !== "—").join(", ") },
      { label: "Address", value: item => item.address }
    ]);
  });
}

async function showDirectoryResults(title, path, columns) {
  const target = document.querySelector("#directory-search-results");
  target.replaceChildren();
  try {
    const rows = await request(path);
    const heading = document.createElement("div");
    heading.className = "panel-heading";
    const titleElement = document.createElement("h3");
    titleElement.textContent = `${title} · ${rows.length}`;
    heading.append(titleElement);
    target.append(heading);
    const table = document.createElement("div");
    target.append(table);
    renderTable(table, columns, rows, "No matches found for those filters.");
  } catch (error) {
    showToast(error.message, true);
  }
}

function bindManagementForms() {
  const rescheduleSelect = document.querySelector('#appointment-action-form select[name="action"]');
  const rescheduleField = document.querySelector("#reschedule-field");
  const rescheduleInput = rescheduleField.querySelector("input");
  const updateRescheduleVisibility = () => {
    const visible = rescheduleSelect.value === "reschedule";
    rescheduleField.hidden = !visible;
    rescheduleInput.required = visible;
  };
  rescheduleSelect.addEventListener("change", updateRescheduleVisibility);
  updateRescheduleVisibility();

  document.querySelector("#appointment-action-form").addEventListener("submit", async event => {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    const path = `${endpoints.appointments}/${encodeURIComponent(values.id)}/${values.action}`;
    const options = { method: "PATCH" };
    if (values.action === "reschedule") {
      options.body = JSON.stringify({ newAppointmentDateTime: values.newAppointmentDateTime });
    }
    await performUpdate(path, options, "Appointment updated.");
  });

  document.querySelector("#record-action-form").addEventListener("submit", async event => {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    const path = `${endpoints.requests}/${encodeURIComponent(values.id)}/${values.action}`;
    const options = { method: "PATCH" };
    if (["approve", "reject", "fulfill"].includes(values.action)) {
      options.body = JSON.stringify({ staffNotes: values.staffNotes.trim() || null });
    }
    await performUpdate(path, options, "Record request updated.");
  });
}

async function performUpdate(path, options, successMessage) {
  try {
    await request(path, options);
    showToast(successMessage);
    await refreshData();
  } catch (error) {
    showToast(error.message, true);
  }
}

function navigate(viewName) {
  const titles = {
    overview: "Overview",
    patients: "Patient care",
    directory: "Care directory",
    records: "Record requests",
    locations: "Locations"
  };
  document.querySelectorAll(".view").forEach(view => view.classList.toggle("active", view.id === `view-${viewName}`));
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.view === viewName));
  document.querySelector("#page-breadcrumb").textContent = titles[viewName] ?? "Overview";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelector("#today-label").textContent = new Intl.DateTimeFormat(undefined, {
    weekday: "short", month: "short", day: "numeric", year: "numeric"
  }).format(new Date());
  document.querySelectorAll(".nav-link").forEach(button => button.addEventListener("click", () => navigate(button.dataset.view)));
  document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
  document.querySelector("#refresh-button").addEventListener("click", () => void refreshData());
  document.querySelectorAll('select[name="countryId"]').forEach(select => {
    select.addEventListener("change", populateOptions);
  });
  bindCreateForms();
  bindSearchForms();
  bindManagementForms();
  void refreshData();
});
