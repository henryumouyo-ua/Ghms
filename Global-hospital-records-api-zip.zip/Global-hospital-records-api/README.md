# Hospital Appointment API

A Spring Boot + Maven REST API that lets a patient find a doctor at a
hospital in their own country, state, or province, and book, cancel, or
reschedule an appointment with them. Built with a layered architecture:
**Model → Repository → Service → Controller**, backed by PostgreSQL.

## Project structure

```
src/main/java/com/hospital/appointment/
├── model/       Entities: Country, StateProvince, Hospital, Doctor, Patient,
│                Appointment, AppointmentStatus
├── repository/   Spring Data JPA repositories
├── service/      Service interfaces
│   └── impl/     Service implementations (business logic)
├── controller/   REST controllers
├── dto/          Request/response DTOs
└── exception/    Custom exceptions + global exception handler
```

See `docs/DATA_MODEL.md` for the full canonical data model — entities, ER
diagram, the appointment status state machine, constraints, and known gaps.

## Prerequisites

- Java 17+
- Maven 3.8+ (or use the included wrapper if you generate one)
- PostgreSQL 13+ running locally
- VS Code with the "Extension Pack for Java" and "Spring Boot Extension Pack"
  (recommended, not required)

## Run with Docker Desktop

Start Docker Desktop, then from the project root run:

```bash
docker compose up --build
```

Compose builds the API image and starts it after PostgreSQL is healthy. The API
and its web interface are available at `http://localhost:8089`; PostgreSQL data is retained in the
`postgres-data` volume between restarts. To stop the services, press `Ctrl+C`
and run `docker compose down`. To also delete the stored database, run
`docker compose down --volumes`.

The Compose file uses `localdevpassword` as a development-only default. Set
`POSTGRES_PASSWORD` in the shell before starting Compose to use a different
password. Do not use the default password outside local development.

The web interface is served by the API container at `/` and sends form
submissions to the REST API. It includes forms and lists for locations,
patients, hospitals, doctors, appointments, and hospital record requests. Use
the interface's refresh button to reload data from the service.

## 1. Set up PostgreSQL

PostgreSQL won't create the database for you automatically — create it once
before running the app:

```bash
createdb hospital_appointments
```

or from `psql`:

```sql
CREATE DATABASE hospital_appointments;
```

## 2. Configure the connection

Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/hospital_appointments
spring.datasource.username=postgres
spring.datasource.password=your_postgres_password
```

Replace the username/password with your own PostgreSQL credentials.

## 3. Run the app

From the project root:

```bash
mvn spring-boot:run
```

Or in VS Code: open the folder, let it import as a Maven project, then
run/debug `HospitalAppointmentApiApplication.java` directly (right-click →
"Run Java").

The API and web interface are available on `http://localhost:8089` when started with Maven.

Hibernate auto-creates all tables on first run
(`spring.jpa.hibernate.ddl-auto=update`). **If you have an existing database
from before the location hierarchy was added**, see the migration note at
the bottom of `docs/DATA_MODEL.md` — `appointments.hospital_id` and
`doctors.hospital_id` are new `NOT NULL` columns that can't be added to a
table that already has rows.

## 4. Try it out — a full walkthrough

The location hierarchy has to be seeded before anything else can reference
it: a `Hospital` needs a `Country` (and optionally a `StateProvince`), and a
`Doctor` needs a `Hospital`.

### Create a country
```bash
curl -X POST http://localhost:8089/api/countries \
  -H "Content-Type: application/json" \
  -d '{"name": "United States", "isoCode": "US"}'
```
→ note the returned `id` (say, `1`).

### Create a state/province (optional, but useful for narrowing searches)
```bash
curl -X POST http://localhost:8089/api/states-provinces \
  -H "Content-Type: application/json" \
  -d '{"name": "California", "code": "CA", "countryId": 1}'
```
→ note the returned `id` (say, `1`).

### Create a hospital
```bash
curl -X POST http://localhost:8089/api/hospitals \
  -H "Content-Type: application/json" \
  -d '{
        "name": "St. Mary General Hospital",
        "address": "123 Main St, San Francisco, CA",
        "countryId": 1,
        "stateProvinceId": 1
      }'
```
→ note the returned `id` (say, `1`).

### Create a doctor at that hospital
```bash
curl -X POST http://localhost:8089/api/doctors \
  -H "Content-Type: application/json" \
  -d '{"fullName": "Dr. Jane Smith", "specialization": "Cardiology", "hospitalId": 1}'
```
→ note the returned `id` (say, `1`).

### Create a patient with their own home location
```bash
curl -X POST http://localhost:8089/api/patients \
  -H "Content-Type: application/json" \
  -d '{
        "fullName": "John Doe",
        "email": "john@example.com",
        "phoneNumber": "555-1234",
        "countryId": 1,
        "stateProvinceId": 1
      }'
```
→ note the returned `id` (say, `1`).

### Find a doctor in your own country/state/province
This is the main "find a doctor near me" endpoint — every filter is
optional, so search by country alone, country + state/province, add a
specialization, or any combination:
```bash
curl "http://localhost:8089/api/doctors/search?countryId=1&stateProvinceId=1&specialization=cardio"
```

You can search hospitals the same way:
```bash
curl "http://localhost:8089/api/hospitals/search?countryId=1&stateProvinceId=1"
```

### Book an appointment
The hospital is derived automatically from the doctor's current hospital —
you don't need to pass it:
```bash
curl -X POST http://localhost:8089/api/appointments \
  -H "Content-Type: application/json" \
  -d '{
        "patientId": 1,
        "doctorId": 1,
        "appointmentDateTime": "2026-10-15T10:00:00",
        "reasonForVisit": "Annual checkup"
      }'
```

### Cancel an appointment
```bash
curl -X PATCH http://localhost:8089/api/appointments/1/cancel
```

### Reschedule an appointment
```bash
curl -X PATCH http://localhost:8089/api/appointments/1/reschedule \
  -H "Content-Type: application/json" \
  -d '{"newAppointmentDateTime": "2026-10-16T14:30:00"}'
```

### Mark an appointment completed
```bash
curl -X PATCH http://localhost:8089/api/appointments/1/complete
```

### View appointments
```bash
curl http://localhost:8089/api/appointments
curl http://localhost:8089/api/appointments/patient/1
curl http://localhost:8089/api/appointments/doctor/1
```

### Request hospital records
A patient can request their own records from a hospital at any time —
optionally scoped to one specific past appointment:
```bash
curl -X POST http://localhost:8089/api/record-requests \
  -H "Content-Type: application/json" \
  -d '{
        "patientId": 1,
        "hospitalId": 1,
        "appointmentId": 1,
        "reason": "Switching primary care providers"
      }'
```
→ note the returned `id` (say, `1`). It starts out `PENDING`.

Hospital staff then move it through its lifecycle (see
`docs/DATA_MODEL.md` section 3.8 for the full state machine):
```bash
# Approve it
curl -X PATCH http://localhost:8089/api/record-requests/1/approve \
  -H "Content-Type: application/json" \
  -d '{"staffNotes": "Records will be sent via the patient portal"}'

# ...then, once delivered, mark it fulfilled
curl -X PATCH http://localhost:8089/api/record-requests/1/fulfill

# Or, instead of approving: reject it (staffNotes explaining why is required)
curl -X PATCH http://localhost:8089/api/record-requests/1/reject \
  -H "Content-Type: application/json" \
  -d '{"staffNotes": "Please submit a photo ID along with this request"}'
```

A patient can also withdraw their own request while it's still `PENDING` or
`APPROVED`:
```bash
curl -X PATCH http://localhost:8089/api/record-requests/1/cancel
```

```bash
curl http://localhost:8089/api/record-requests/patient/1
curl http://localhost:8089/api/record-requests/hospital/1
```

## API summary

| Method | Endpoint                                 | Description                      |
|--------|---------------------------------------------|------------------------------------|
| POST   | `/api/countries`                         | Create a country                 |
| GET    | `/api/countries`                         | List countries                   |
| GET    | `/api/countries/{id}`                    | Get a country                    |
| POST   | `/api/states-provinces`                  | Create a state/province          |
| GET    | `/api/states-provinces?countryId=`       | List states/provinces (optionally scoped to a country) |
| GET    | `/api/states-provinces/{id}`             | Get a state/province             |
| POST   | `/api/hospitals`                         | Create a hospital                |
| GET    | `/api/hospitals`                         | List active hospitals            |
| GET    | `/api/hospitals/{id}`                    | Get a hospital                   |
| GET    | `/api/hospitals/search?countryId=&stateProvinceId=` | Find hospitals by location |
| DELETE | `/api/hospitals/{id}`                    | Deactivate a hospital (soft delete) |
| POST   | `/api/patients`                          | Create a patient                 |
| GET    | `/api/patients`                          | List active patients             |
| GET    | `/api/patients/{id}`                     | Get a patient                    |
| DELETE | `/api/patients/{id}`                     | Deactivate a patient (soft delete) |
| POST   | `/api/doctors`                           | Create a doctor                  |
| GET    | `/api/doctors`                           | List active doctors              |
| GET    | `/api/doctors/{id}`                      | Get a doctor                     |
| GET    | `/api/doctors/search?countryId=&stateProvinceId=&hospitalId=&specialization=` | Find a doctor by location/specialization |
| DELETE | `/api/doctors/{id}`                      | Deactivate a doctor (soft delete) |
| POST   | `/api/appointments`                      | Book an appointment              |
| GET    | `/api/appointments`                      | List all appointments            |
| GET    | `/api/appointments/{id}`                 | Get one appointment              |
| PATCH  | `/api/appointments/{id}/cancel`          | Cancel an appointment            |
| PATCH  | `/api/appointments/{id}/reschedule`      | Reschedule an appointment        |
| PATCH  | `/api/appointments/{id}/complete`        | Mark an appointment completed    |
| GET    | `/api/appointments/patient/{patientId}`  | List a patient's appointments    |
| GET    | `/api/appointments/doctor/{doctorId}`    | List a doctor's appointments     |
| POST   | `/api/record-requests`                   | Patient requests their hospital records |
| GET    | `/api/record-requests`                   | List all record requests         |
| GET    | `/api/record-requests/{id}`               | Get one record request           |
| PATCH  | `/api/record-requests/{id}/cancel`        | Patient withdraws their request  |
| PATCH  | `/api/record-requests/{id}/approve`       | Hospital staff approves it       |
| PATCH  | `/api/record-requests/{id}/reject`        | Hospital staff rejects it (requires `staffNotes`) |
| PATCH  | `/api/record-requests/{id}/fulfill`       | Hospital staff marks it delivered |
| GET    | `/api/record-requests/patient/{patientId}`| List a patient's record requests |
| GET    | `/api/record-requests/hospital/{hospitalId}` | List a hospital's record requests |

## Notes / things worth knowing

- A `Hospital` requires a `countryId`; `stateProvinceId` is optional (not
  every country is meaningfully subdivided). A `Patient` works the same way.
  If you do supply a `stateProvinceId`, it must actually belong to the
  `countryId` you supplied — otherwise you get a `400` with a clear message.
- A `Doctor` belongs to exactly one `Hospital`. An `Appointment` captures
  that hospital automatically at booking time, so appointment history stays
  accurate even if the doctor later moves to a different hospital.
- Booking and rescheduling both check that the doctor isn't already booked
  at that exact date/time (excluding cancelled appointments), and reject
  with `409 Conflict` if so. Booking also checks that the doctor and their
  hospital are both active.
- `appointmentDateTime` must be in the future (validated via `@Future`).
- Validation errors return `400` with a `fieldErrors` map; cross-entity
  mismatches (like a state/province that doesn't belong to the given
  country) return `400` with a plain error message; not-found resources
  return `404`; scheduling conflicts return `409`.
- `DELETE /api/patients/{id}`, `DELETE /api/doctors/{id}`, and
  `DELETE /api/hospitals/{id}` are **soft** deletes — they set
  `active = false` rather than removing the row, so appointment history is
  preserved. Deactivated records drop out of the default `GET` list and
  search endpoints but can still be fetched directly by id. There's
  currently no "reactivate" endpoint for any of them.
- `Country` and `StateProvince` have no delete endpoint — see
  `docs/DATA_MODEL.md` section 6.3 for why.
- A `HospitalRecordRequest` models a patient asking for their own records
  from a hospital, with its own lifecycle (`PENDING` → `APPROVED`/`REJECTED`
  → `FULFILLED`, or `CANCELLED` by the patient). It can optionally be scoped
  to one specific past appointment, which must belong to the same patient
  and hospital. This models the *request workflow* only — there's no actual
  file/document delivery mechanism behind `FULFILLED` (see
  `docs/DATA_MODEL.md` section 6.9).
- Approve/reject/fulfill on a record request are written as hospital-staff
  actions, but nothing currently enforces that distinction — a patient can
  call them too. This is the same authentication gap as everywhere else in
  this API (next bullet), just worth calling out explicitly here since it's
  more consequential for this endpoint than most.
- This is a starting point, not a production-hardened service — there's no
  authentication/authorization layer, so you'll want to add Spring Security
  (or similar) before exposing this beyond local development.
